//
// 演示如何通过 UITableViewController 实现下拉刷新
//
// 注意：
// 1、这里需要继承的是 UITableViewController, 而不是 UIViewController
// 2、仅 ios6 或以上支持
// 3、建议使用第三方开源库来实现下拉刷新：EGOTableViewPullRefresh
//

#import <UIKit/UIKit.h>

@interface WTableView10Controller : UITableViewController

@end
