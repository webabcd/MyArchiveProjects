//
// 演示 NavigationController 的应用
//

#import <UIKit/UIKit.h>

@interface WNavigationControllerController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lblMsg;

@end
