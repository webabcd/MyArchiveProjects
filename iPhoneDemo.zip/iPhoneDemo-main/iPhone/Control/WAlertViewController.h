//
// 演示 UIAlertView 的应用
//

#import <UIKit/UIKit.h>

@interface WAlertViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lblMsg;

@end
