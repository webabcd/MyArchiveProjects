//
// 本地化 app 的准备工作
//
// 1、先按本例图片演示的那样，进入到 PROJECT -> Info
// 2、然后设置 Localizations
//
// 文字，图片，文件，xib，storyboard 等都可以本地化
//

#import "WLocalizationReadyController.h"

@interface WLocalizationReadyController ()

@end

@implementation WLocalizationReadyController

- (void)viewDidLoad
{
    [super viewDidLoad];
}

@end
