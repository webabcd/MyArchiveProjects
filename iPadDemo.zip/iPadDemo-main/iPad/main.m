//
//  main.m
//  iPad
//
//  Created by iMac on 1/7/14.
//  Copyright (c) 2014 webabcd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "WAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([WAppDelegate class]));
    }
}
