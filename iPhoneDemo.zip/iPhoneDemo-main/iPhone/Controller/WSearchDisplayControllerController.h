//
// 演示 UISearchDisplayController 的应用
//

#import <UIKit/UIKit.h>

@interface WSearchDisplayControllerController : UIViewController

@end
