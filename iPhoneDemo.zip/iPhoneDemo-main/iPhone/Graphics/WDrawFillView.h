//
// 演示填充、渐变、阴影的应用
//

#import <UIKit/UIKit.h>

@interface WDrawFillView : UIView

@end
