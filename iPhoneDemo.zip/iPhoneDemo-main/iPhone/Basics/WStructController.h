//
// 用于演示如何使用结构体
//

#import <UIKit/UIKit.h>
#import "WPoint.h"

@interface WStructController : UIViewController

@end
