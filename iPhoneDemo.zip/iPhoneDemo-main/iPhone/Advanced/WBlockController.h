//
// 演示 Block 的应用
//

#import <UIKit/UIKit.h>

@interface WBlockController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lblMsg;

@end
