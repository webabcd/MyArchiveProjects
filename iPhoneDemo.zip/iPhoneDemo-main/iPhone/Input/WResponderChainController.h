//
// 演示响应者链的概念
//

#import <UIKit/UIKit.h>
// 引入 WResponderChainDemo
#import "WResponderChainDemo.h"

@interface WResponderChainController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lblMsg;

@end
