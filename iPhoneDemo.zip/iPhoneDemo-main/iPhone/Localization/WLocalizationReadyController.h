//
// 本地化 app 的准备工作
//

#import <UIKit/UIKit.h>

@interface WLocalizationReadyController : UIViewController

@end
