//
// 演示如何实现动画效果
//

#import <UIKit/UIKit.h>

@interface WAnimationDemoController : UIViewController

@end
