//
// 演示 xml 的解析
//

#import <UIKit/UIKit.h>

@interface WXmlController : UIViewController<NSXMLParserDelegate>

@property (weak, nonatomic) IBOutlet UILabel *lblMsg;

@end
