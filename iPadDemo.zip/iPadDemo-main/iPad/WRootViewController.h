//
// UISplitViewController 的 rootView（左侧 view）
//

#import <UIKit/UIKit.h>

@interface WRootViewController : UITableViewController

@end
