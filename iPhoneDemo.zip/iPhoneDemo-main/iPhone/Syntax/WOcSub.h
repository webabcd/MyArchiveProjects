//
// 演示类继承的相关知识
//
// 本类用于演示子类
//

#import <Foundation/Foundation.h>
#import "WOcSuper.h"

@interface WOcSub : WOcSuper

@end
