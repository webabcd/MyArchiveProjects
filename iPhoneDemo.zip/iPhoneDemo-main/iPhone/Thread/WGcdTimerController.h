//
// 演示 GCD Timer
//

#import <UIKit/UIKit.h>

@interface WGcdTimerController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lblMsg;

@end
