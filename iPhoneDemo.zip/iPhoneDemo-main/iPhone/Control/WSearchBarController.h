//
// 演示 UISearchBar 的应用
//

#import <UIKit/UIKit.h>

@interface WSearchBarController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lblMsg;
@property (weak, nonatomic) IBOutlet UISearchBar *searchBar;

@end
