# iPad Demo（2013年写的）


1. UIActivityViewController
2. UIPopoverController
3. UISplitViewController