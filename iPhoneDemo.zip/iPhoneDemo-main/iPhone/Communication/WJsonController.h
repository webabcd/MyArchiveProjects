//
// 演示 json 的解析，以及 json 的生成
//

#import <UIKit/UIKit.h>

@interface WJsonController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lblMsg;

@end
