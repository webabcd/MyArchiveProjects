//
// 演示 UIPickerView 的应用
//

#import <UIKit/UIKit.h>

@interface WPickerViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lblMsg;
@property (weak, nonatomic) IBOutlet UIPickerView *pickerView;

@end
