//
// 演示如何在 UITableView 的编辑状态下，对 cell 做新增、删除和批量删除操作
//

#import <UIKit/UIKit.h>

@interface WTableView8Controller : UIViewController

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIToolbar *toolBar;

@end
