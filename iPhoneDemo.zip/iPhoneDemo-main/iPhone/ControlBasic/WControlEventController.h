//
// 演示 UIControlEvent 的应用，即 target/action 的应用
//

#import <UIKit/UIKit.h>

@interface WControlEventController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lblMsg;
@property (weak, nonatomic) IBOutlet UIButton *btnDemo;
@property (weak, nonatomic) IBOutlet UILabel *lblMsg2;
@property (weak, nonatomic) IBOutlet UIButton *btnDemo2;

@end
