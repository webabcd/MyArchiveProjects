//
// 演示如何获取当前语言类型，以及如何动态设置当前语言
//

#import <UIKit/UIKit.h>

@interface WLocalizationDemoController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lblMsg;
@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@end
