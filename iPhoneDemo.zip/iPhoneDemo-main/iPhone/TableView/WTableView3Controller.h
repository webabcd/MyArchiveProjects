//
// 演示如何自定义 UITableView 的单元格样式
//

#import <UIKit/UIKit.h>
// 引入自定义 cell
#import "WCustomTableViewCell.h"

@interface WTableView3Controller : UIViewController

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end
