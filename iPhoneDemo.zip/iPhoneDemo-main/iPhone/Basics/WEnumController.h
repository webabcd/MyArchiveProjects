//
// 用于演示如何使用枚举
//

#import <UIKit/UIKit.h>
#import "WMonth.h"

@interface WEnumController : UIViewController

@end
