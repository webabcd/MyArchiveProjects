//
// 演示如何通过 CGContextClip 剪切图片
//

#import <UIKit/UIKit.h>

@interface WClipController : UIViewController

@end
