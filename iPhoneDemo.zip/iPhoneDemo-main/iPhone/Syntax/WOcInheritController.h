//
// 用于演示类继承
//

#import <UIKit/UIKit.h>
#import "WOcSub.h"
#import "WOcSuper.h"

@interface WOcInheritController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lblMsg;
@property (weak, nonatomic) IBOutlet UILabel *lblMsg2;
@property (weak, nonatomic) IBOutlet UILabel *lblMsg3;
@property (weak, nonatomic) IBOutlet UILabel *lblMsg4;
@property (weak, nonatomic) IBOutlet UILabel *lblMsg5;
@property (weak, nonatomic) IBOutlet UILabel *lblMsg6;

@end
