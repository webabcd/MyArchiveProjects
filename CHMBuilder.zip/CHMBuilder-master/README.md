﻿# CHMBuilder


##### 用途
  CHM（Compiled Help Manual）文件实际上就是将一堆 html 文件编译为一个 CHM 文件。本例用于将你选中的 html 目录编译为一个 chm 文件


##### 开发工具和运行环境
  visual studio 2017 + .net framework 4.5