//
// 演示 UIActivityIndicatorView 的应用
//

#import <UIKit/UIKit.h>

@interface WActivityIndicatorViewController : UIViewController

@end
