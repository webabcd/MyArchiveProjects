//
//  WDownloadController.h
//  iPhone
//
//  Created by iMac on 2/18/14.
//  Copyright (c) 2014 webabcd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WDownloadController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lblMsg;
@property (weak, nonatomic) IBOutlet UIProgressView *progressView;

@end
