//
// 演示 UIToolbar UIBarButtonItem 的应用
//

#import <UIKit/UIKit.h>

@interface WToolbarController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lblMsg;

@end
