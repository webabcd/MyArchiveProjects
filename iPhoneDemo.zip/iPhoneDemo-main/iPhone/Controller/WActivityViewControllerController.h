//
// 演示 UIActivityViewController 的应用
//

#import <UIKit/UIKit.h>

@interface WActivityViewControllerController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lblMsg;

@end
