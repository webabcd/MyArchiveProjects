//
// 演示如何通过 Core Graphics 绘制各种形状
//
#import <UIKit/UIKit.h>

@interface WDrawShapeView : UIView

@end
