//
//  WAppDelegate.h
//  iPad
//
//  Created by iMac on 1/7/14.
//  Copyright (c) 2014 webabcd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
