//
// 演示 UIDatePicker 的应用
//

#import <UIKit/UIKit.h>

@interface WDatePickerController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lblMsg;
@property (weak, nonatomic) IBOutlet UIDatePicker *datePicker;

@end
