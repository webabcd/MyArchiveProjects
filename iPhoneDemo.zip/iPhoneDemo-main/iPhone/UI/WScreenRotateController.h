//
// 演示如何自动或手动旋转屏幕
//

#import <UIKit/UIKit.h>

@interface WScreenRotateController : UIViewController

@end
