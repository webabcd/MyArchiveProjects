//
// Icon Title 的本地化
//

#import <UIKit/UIKit.h>

@interface WLocalizationIconTitleController : UIViewController

@end
