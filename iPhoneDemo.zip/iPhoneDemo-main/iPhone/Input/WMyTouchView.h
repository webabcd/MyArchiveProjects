//
// 用于演示 touch 的 UIView
//

#import <UIKit/UIKit.h>

@interface WMyTouchView : UIView

// 在此 UIView 上放一个 UILabel，用于显示相关 touch 信息
@property (nonatomic, strong) UILabel *lblMsg;

@end
