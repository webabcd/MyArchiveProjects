#import <Foundation/Foundation.h>

// c 语言的结构体
typedef struct
{
    int x;
    int y;
} WPointC;

// oc 语言的结构体
struct WPointOC
{
    int x;
    int y;
};