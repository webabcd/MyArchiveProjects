//
// 字符串的本地化
//

#import <UIKit/UIKit.h>

@interface WLocalizationTextController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lblMsg;

@end
