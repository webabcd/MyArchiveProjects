//
// 演示 copy 的概念
//

#import <UIKit/UIKit.h>

@interface WCopyController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lblMsg;

@end
