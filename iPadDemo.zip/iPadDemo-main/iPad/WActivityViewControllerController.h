//
// 演示 UIActivityViewController 的应用
//

#import <UIKit/UIKit.h>

@interface WActivityViewControllerController : UIViewController

@end
