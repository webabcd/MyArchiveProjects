//
// 演示 group queue
//

#import <UIKit/UIKit.h>

@interface WGcdGroupQueueController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lblMsg;
@property (weak, nonatomic) IBOutlet UILabel *lblMsg2;

@end
