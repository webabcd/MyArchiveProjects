//
// 演示 UILabel 的应用
//

#import <UIKit/UIKit.h>

@interface WLabelController : UIViewController

@end
