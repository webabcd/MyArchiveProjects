//
// 演示 NSNotificationCenter 的应用
//

#import <UIKit/UIKit.h>

@interface WNotificationCenterController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lblMsg;

@end
