//
// 演示 UIImageView 的应用
//

#import <UIKit/UIKit.h>

@interface WImageViewController : UIViewController

@end
