//
// 演示 NSThread 的应用
//

#import <UIKit/UIKit.h>

@interface WThreadDemoController : UIViewController

@property (weak, nonatomic) IBOutlet UIButton *btnLoadRemoteImage;
@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@end
