//
// 演示 UIScrollView 的应用
//

#import <UIKit/UIKit.h>

@interface WScrollViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lblMsg;
@property (weak, nonatomic) IBOutlet UILabel *lblMsg2;
@property (weak, nonatomic) IBOutlet UILabel *lblMsg3;
@property (weak, nonatomic) IBOutlet UILabel *lblMsg4;

@end
