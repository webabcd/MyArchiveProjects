//
// 演示 UISegmentedControl 的应用
//

#import <UIKit/UIKit.h>

@interface WSegmentedControlController : UIViewController

@end
