//
// 我是此 app 的 rootViewController 的一个 subclass
//

#import <UIKit/UIKit.h>

// 我是 rootViewController 的子类，而 rootViewController 是一个 UINavigationController（参看 Main.storyboard），所以这里要继承 UINavigationController
@interface WNavigationController : UINavigationController

@end
