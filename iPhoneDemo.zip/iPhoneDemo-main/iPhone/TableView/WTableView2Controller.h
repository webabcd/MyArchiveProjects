//
// 演示如何通过 UITableView 显示列表数据（定义样式和行为）
//

#import <UIKit/UIKit.h>

@interface WTableView2Controller : UIViewController

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end
