//
// 演示 NSConditionLock, NSCondition 的应用
//

#import <UIKit/UIKit.h>

@interface WThreadConditionController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lblMsg;

@end
