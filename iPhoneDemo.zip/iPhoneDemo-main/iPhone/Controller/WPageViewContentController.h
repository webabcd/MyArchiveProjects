//
//  WPageViewContentController.h
//  iPhone
//
//  Created by iMac on 1/14/14.
//  Copyright (c) 2014 webabcd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WPageViewContentController : UIViewController

@property (nonatomic, strong) UILabel *label;
@property (nonatomic, strong) NSString *displayString;

@end
