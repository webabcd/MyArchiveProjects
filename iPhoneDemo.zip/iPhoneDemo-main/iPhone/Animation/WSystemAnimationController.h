//
// 演示系统动画的应用
//

#import <UIKit/UIKit.h>

@interface WSystemAnimationController : UIViewController

@end
