//
// 各种 dispatch 的说明
//

#import <UIKit/UIKit.h>

@interface WGcdDispatchFunctionController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lblMsg;

@end
