//
// 演示 private queue
//

#import <UIKit/UIKit.h>

@interface WGcdPrivateQueueController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lblMsg;
@property (weak, nonatomic) IBOutlet UILabel *lblMsg2;

@end
