//
// 演示 UIPageViewController 的应用
//

#import <UIKit/UIKit.h>

@interface WPageViewControllerController : UIViewController

@end
