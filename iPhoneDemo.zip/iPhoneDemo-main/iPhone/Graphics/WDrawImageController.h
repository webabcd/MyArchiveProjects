//
// 演示如何 draw image, 以及图像九宫格的应用
//

#import <UIKit/UIKit.h>

@interface WDrawImageController : UIViewController

@end
