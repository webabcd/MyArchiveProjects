//
// 演示如何做 http 通信
//

#import <UIKit/UIKit.h>

@interface WHttpController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lblMsg;

@end
