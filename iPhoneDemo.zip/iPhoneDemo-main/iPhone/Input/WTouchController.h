//
// 演示 touch 的应用
//

#import <UIKit/UIKit.h>
// 引入 WMyTouchView
#import "WMyTouchView.h"

@interface WTouchController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lblMsg;

@end
