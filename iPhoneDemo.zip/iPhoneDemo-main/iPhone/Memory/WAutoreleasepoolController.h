//
//  WAutoreleasepoolController.h
//  iPhone
//
//  Created by wanglei on 5/18/15.
//  Copyright (c) 2015 webabcd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WAutoreleasepoolController : UIViewController

@end
