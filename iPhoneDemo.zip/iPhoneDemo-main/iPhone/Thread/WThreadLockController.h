//
// 演示 NSLock @synchronized 的应用
//

#import <UIKit/UIKit.h>

@interface WThreadLockController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lblMsg;

@end
