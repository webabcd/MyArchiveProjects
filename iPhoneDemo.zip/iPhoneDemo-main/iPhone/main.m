//
//  main.m
//  iPhone
//
//  Created by iMac on 12/3/13.
//  Copyright (c) 2013 webabcd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "WAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([WAppDelegate class]));
    }
}
