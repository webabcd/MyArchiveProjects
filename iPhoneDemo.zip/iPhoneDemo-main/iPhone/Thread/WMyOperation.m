//
//  WMyOperation.m
//  iPhone
//
//  Created by iMac on 12/18/13.
//  Copyright (c) 2013 webabcd. All rights reserved.
//

#import "WMyOperation.h"

@implementation WMyOperation

- (void)main
{
    
}

@end
