//
//  WMyOperation.h
//  iPhone
//
//  Created by iMac on 12/18/13.
//  Copyright (c) 2013 webabcd. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WMyOperation : NSOperation

@end
