//
// 演示 UISlider 的应用
//

#import <UIKit/UIKit.h>

@interface WSliderController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lblMsg;
@property (weak, nonatomic) IBOutlet UISlider *slider;

@property (weak, nonatomic) IBOutlet UILabel *lblMsg2;
@property (weak, nonatomic) IBOutlet UISlider *slider2;

@end
