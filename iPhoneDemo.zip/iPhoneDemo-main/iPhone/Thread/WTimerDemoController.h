//
// 演示 NSTimer 的应用（在 UI 线程上）
//

#import <UIKit/UIKit.h>

@interface WTimerDemoController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lblMsg;

@end
