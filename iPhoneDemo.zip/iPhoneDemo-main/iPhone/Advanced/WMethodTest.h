//
// 一个具有一个方法的类，用于演示 SEL @selector
//

#import <Foundation/Foundation.h>

@interface WMethodTest : NSObject

- (NSString *)method:(NSString*)name;

@end
