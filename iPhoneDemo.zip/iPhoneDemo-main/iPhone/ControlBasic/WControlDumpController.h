//
// 演示如何 dump 出一个 UIView 内部的全部 UIView 层级结构
//

#import <UIKit/UIKit.h>

@interface WControlDumpController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lblMsg;

@end
