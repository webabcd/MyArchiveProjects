//
// 演示 UIStepper 的应用
//

#import <UIKit/UIKit.h>

@interface WStepperController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lblMsg;

@end
