//
// 演示如何获取分辨率，以及如何适应分辨率
//

#import <UIKit/UIKit.h>

@interface WResolutionController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lblMsg;
@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@end
