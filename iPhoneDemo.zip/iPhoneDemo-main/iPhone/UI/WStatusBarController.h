//
// 演示 UIStatusBar 的应用
//

#import <UIKit/UIKit.h>

@interface WStatusBarController : UIViewController

@end
