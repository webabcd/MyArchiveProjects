//
// 演示 UISwitch 的应用
//

#import <UIKit/UIKit.h>

@interface WSwitchController : UIViewController

@end
