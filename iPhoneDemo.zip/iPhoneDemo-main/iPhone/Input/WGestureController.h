//
// 演示如何识别和响应手势
//

#import <UIKit/UIKit.h>

@interface WGestureController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lblMsg;

@end
