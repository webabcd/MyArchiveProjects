//
// 演示如何 draw string
//

#import <UIKit/UIKit.h>

@interface WDrawStringView : UIView

@end
