//
// 演示 main queue 和 global queue
//

#import <UIKit/UIKit.h>

@interface WGcdMainQueueAndGlobalQueueController : UIViewController

@property (weak, nonatomic) IBOutlet UIButton *btnLoadRemoteImage;
@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@end
