//
// 演示如何实现 cell 的滑动删除
//

#import <UIKit/UIKit.h>

@interface WTableView7Controller : UIViewController

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end
