//
// 演示如何为 cell 增加上下文菜单
//

#import <UIKit/UIKit.h>

@interface WTableView6Controller : UIViewController

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end
