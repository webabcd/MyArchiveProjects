//
//  WControlEventTouchController.h
//  iPhone
//
//  Created by iMac on 12/19/13.
//  Copyright (c) 2013 webabcd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WControlEventTouchController : UIViewController

@end
