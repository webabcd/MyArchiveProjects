//
// 演示 cell 右侧扩展按钮（disclosure button）的应用
//

#import <UIKit/UIKit.h>

@interface WTableView5Controller : UIViewController

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end
