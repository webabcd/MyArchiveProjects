//
// 图片的本地化
//

#import <UIKit/UIKit.h>

@interface WLocalizationImageController : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@end
