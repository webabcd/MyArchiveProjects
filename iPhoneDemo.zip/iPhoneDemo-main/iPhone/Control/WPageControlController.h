//
// 演示 UIPageControl 的应用
//

#import <UIKit/UIKit.h>

@interface WPageControlController : UIViewController

@end
