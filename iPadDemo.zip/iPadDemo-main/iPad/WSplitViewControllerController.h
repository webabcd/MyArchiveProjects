//
// 演示 UISplitViewController 的应用
//

#import <UIKit/UIKit.h>

@interface WSplitViewControllerController : UIViewController

@end
