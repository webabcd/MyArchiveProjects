//
// 演示如何通过 UITableView 显示列表数据（多种内置样式）
//

#import <UIKit/UIKit.h>

@interface WTableView1Controller : UIViewController

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end
